Internationalization
====================


To translate the plugin in your language, please visit https://translate.wordpress.org/projects/wp-plugins/quotes-collection
